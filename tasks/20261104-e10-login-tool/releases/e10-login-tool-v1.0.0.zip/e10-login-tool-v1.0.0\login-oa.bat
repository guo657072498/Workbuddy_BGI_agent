@echo off
rem e10-login-tool - one-click OA login state setup (v1.0.0)
rem Requires: Node.js >= 22 and system Edge/Chrome (Windows)

where node >nul 2>nul
if errorlevel 1 (
  echo [X] Node.js not found.
  echo     Please install Node.js 22 or newer from https://nodejs.org/
  echo     then run this file again.
  pause
  exit /b 1
)

echo Checking Node.js...
node --version
echo.
echo Starting OA login. A browser window will open.
echo Please login as usual (IAM SSO / QR code). The window closes
echo automatically after login succeeds.
echo.
node "%~dp0src\get-oa-cookie.mjs"
echo.
pause
