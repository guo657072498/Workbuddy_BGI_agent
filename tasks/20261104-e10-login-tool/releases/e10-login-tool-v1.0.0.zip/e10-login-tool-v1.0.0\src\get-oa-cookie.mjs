/**
 * get-oa-cookie.mjs — OA 登录态自动获取脚本（零依赖版 v2）
 *
 * 原理：用系统已装的 Edge/Chrome 开一个独立临时配置的浏览器窗口，
 * 用户按平时的方式登录 OA（IAM 跳转/扫码照旧）。脚本通过 CDP 协议
 * 轮询窗口 cookie，发现 ETEAMSID 后交给 e10-login set 做有效性校验
 * （teamsCheck 实时验证，匿名会话不过关），有效才写入加密认证文件。
 *
 * 零依赖：无需 npm install。要求 Node >= 22 + Windows 自带 Edge。
 * e10-login 从本包 vendor/ 目录调用（免安装）。
 *
 * 凭据只在本地流转：不打印 ETEAMSID 本体、不回显、不进入 AI 对话。
 *
 * 用法：
 *   node get-oa-cookie.mjs                  # 默认 https://oa.bgi.com
 *   node get-oa-cookie.mjs https://oa.xxx.cn
 */
import { spawn } from 'node:child_process';
import net from 'node:net';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const BASE_URL = (process.argv[2] || 'https://oa.bgi.com').replace(/\/+$/, '');
const HOSTNAME = new URL(BASE_URL).hostname;
const TIMEOUT_MS = 5 * 60 * 1000;
const POLL_MS = 2000;

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// e10-login 入口：优先 vendor（随包分发），回退工作区 tools/
const VENDOR_BIN = path.resolve(__dirname, '..', 'vendor', 'e10-login', 'node_modules', 'e10-login', 'bin', 'e10-login.js');
const WORKSPACE_BIN = path.resolve(__dirname, '..', '..', '..', 'tools', 'e10-login', 'node_modules', 'e10-login', 'bin', 'e10-login.js');
const E10_LOGIN_JS = fs.existsSync(VENDOR_BIN) ? VENDOR_BIN : WORKSPACE_BIN;

/** 找系统已装的 Edge / Chrome（可用环境变量 E10_BROWSER=edge|chrome 强制指定） */
function findBrowser() {
  const pf = process.env['ProgramFiles'] || 'C:\\Program Files';
  const pf86 = process.env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)';
  const lad = process.env['LOCALAPPDATA'] || '';
  const EDGE = [
    path.join(pf86, 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
    path.join(pf, 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
  ];
  const CHROME = [
    path.join(pf86, 'Google', 'Chrome', 'Application', 'chrome.exe'),
    path.join(pf, 'Google', 'Chrome', 'Application', 'chrome.exe'),
    path.join(lad, 'Google', 'Chrome', 'Application', 'chrome.exe'),
  ];
  const force = (process.env.E10_BROWSER || '').toLowerCase();
  const list = force === 'edge' ? EDGE
    : force === 'chrome' ? CHROME
    : [...EDGE, ...CHROME];
  return list.find((p) => p && fs.existsSync(p));
}

/** 取一个空闲本地端口 */
function freePort() {
  return new Promise((resolve, reject) => {
    const s = net.createServer();
    s.listen(0, '127.0.0.1', () => {
      const p = s.address().port;
      s.close(() => resolve(p));
    });
    s.on('error', reject);
  });
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** 简易 CDP 调用（同一时刻单请求，够用） */
let wsSeq = 1;
function cdp(ws, method, params = {}) {
  return new Promise((resolve, reject) => {
    const id = wsSeq++;
    const onMsg = (ev) => {
      const m = JSON.parse(ev.data);
      if (m.id === id) {
        ws.removeEventListener('message', onMsg);
        m.error ? reject(new Error(m.error.message)) : resolve(m.result);
      }
    };
    ws.addEventListener('message', onMsg);
    ws.send(JSON.stringify({ id, method, params }));
  });
}

/** cookie domain 是否归属目标主机（兼容 .bgi.com / oa.bgi.com） */
function hostMatch(domain) {
  const d = (domain || '').replace(/^\./, '').toLowerCase();
  return HOSTNAME === d || HOSTNAME.endsWith('.' + d);
}

/** 调 e10-login set 写入登录态（内部含 teamsCheck 有效性校验） */
function runSet(eteamsid) {
  return new Promise((resolve) => {
    const env = { ...process.env };
    delete env.NODE_OPTIONS;
    const child = spawn(
      process.execPath,
      [E10_LOGIN_JS, 'set', '--eteamsid', eteamsid, '--base-url', BASE_URL],
      { env, stdio: ['ignore', 'pipe', 'pipe'] }
    );
    let out = '';
    child.stdout.on('data', (d) => { out += d; });
    child.stderr.on('data', (d) => { out += d; });
    child.on('close', (code) => resolve({ code, out }));
    child.on('error', () => resolve({ code: 1, out: '' }));
  });
}

async function main() {
  const browserExe = findBrowser();
  if (!browserExe) {
    console.error('[X] 未找到 Edge/Chrome，请确认系统已安装');
    process.exit(1);
  }
  if (!fs.existsSync(E10_LOGIN_JS)) {
    console.error('[X] 未找到 e10-login（vendor/ 缺失），请使用完整工具包');
    process.exit(1);
  }

  const port = await freePort();
  const profileDir = fs.mkdtempSync(path.join(os.tmpdir(), 'e10-login-'));
  const browser = spawn(browserExe, [
    `--remote-debugging-port=${port}`,
    `--user-data-dir=${profileDir}`,
    '--no-first-run',
    '--no-default-browser-check',
    BASE_URL,
  ], { stdio: 'ignore' });

  const cleanup = async (ws) => {
    try { if (ws && ws.readyState === 1) await cdp(ws, 'Browser.close'); } catch { /* ignore */ }
    browser.kill();
    await sleep(800);
    try { fs.rmSync(profileDir, { recursive: true, force: true }); } catch { /* ignore */ }
  };

  // 等调试端口就绪
  let version = null;
  for (let i = 0; i < 20; i++) {
    try {
      const r = await fetch(`http://127.0.0.1:${port}/json/version`);
      if (r.ok) { version = await r.json(); break; }
    } catch { /* 未就绪，继续等 */ }
    if (browser.exitCode !== null) {
      console.error('[X] 浏览器启动失败，退出');
      process.exit(1);
    }
    await sleep(500);
  }
  if (!version) {
    console.error('[X] 浏览器调试端口未就绪，退出');
    await cleanup(null);
    process.exit(1);
  }

  // 连 CDP
  const ws = new WebSocket(version.webSocketDebuggerUrl);
  await new Promise((resolve, reject) => {
    ws.addEventListener('open', resolve);
    ws.addEventListener('error', () => reject(new Error('CDP 连接失败')));
  });

  console.log('\n👉 请在打开的浏览器窗口中完成登录（IAM 跳转 / 扫码，一切照旧）。');
  console.log('   登录成功后窗口会自动关闭，无需其他操作。\n');

  const start = Date.now();
  let cdpOkLogged = false;
  let tryingLogged = false;
  let browserClosed = false;
  browser.on('exit', () => { browserClosed = true; });

  while (Date.now() - start < TIMEOUT_MS) {
    if (browserClosed) {
      console.log('[X] 浏览器窗口被关闭，未完成登录，退出');
      try { fs.rmSync(profileDir, { recursive: true, force: true }); } catch { /* ignore */ }
      process.exit(2);
    }

    let cookies = [];
    try {
      const r = await cdp(ws, 'Storage.getCookies');
      cookies = (r && r.cookies) || [];
    } catch { /* 下轮重试 */ }

    const mine = cookies.filter((c) => hostMatch(c.domain));
    if (mine.length > 0 && !cdpOkLogged) {
      cdpOkLogged = true;
      console.log(`CDP 连接正常，已能读取浏览器 cookie（当前 ${mine.length} 条），等待登录…`);
    }

    const et = mine.find((c) => c.name === 'ETEAMSID' && c.value);
    if (et) {
      const { code, out } = await runSet(et.value);
      if (code === 0) {
        console.log(out.trim());
        console.log('\n[OK] 登录态已写入本地认证文件（加密保存），窗口即将关闭');
        await cleanup(ws);
        process.exit(0);
      }
      if (!tryingLogged) {
        tryingLogged = true;
        console.log('检测到初步会话，等待登录完成后自动校验…');
      }
    }
    await sleep(POLL_MS);
  }

  console.error('[X] 5 分钟内未完成登录，退出');
  await cleanup(ws);
  process.exit(3);
}

main().catch(async (e) => {
  console.error('脚本异常:', e.message);
  process.exit(1);
});
